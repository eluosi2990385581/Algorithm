#include "RedBlackTree.templates.h"

template class RedBlackTree<int>;

template class RedBlackTree<long>;

template class RedBlackTree<float>;

template class RedBlackTree<double>;

template class RedBlackTree<char>;
