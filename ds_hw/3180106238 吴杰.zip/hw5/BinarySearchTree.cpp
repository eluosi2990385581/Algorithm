#include "BinarySearchTree.templates.h"

template class BinarySearchTree<int>;

template class BinarySearchTree<long>;

template class BinarySearchTree<float>;

template class BinarySearchTree<double>;

template class BinarySearchTree<char>;

