#include "BinaryTree.templates.h"

template class BinaryTree<int>;

template class BinaryTree<long>;

template class BinaryTree<float>;

template class BinaryTree<double>;

template class BinaryTree<char>;

