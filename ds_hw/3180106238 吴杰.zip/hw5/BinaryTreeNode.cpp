#include "BinaryTreeNode.templates.h"

template class BinaryTreeNode<int>;

template class BinaryTreeNode<long>;

template class BinaryTreeNode<float>;

template class BinaryTreeNode<double>;

template class BinaryTreeNode<char>;
